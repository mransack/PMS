import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { Appointment } from '../../models/Appointment';
import { Observable } from 'rxjs';
import {MatPaginator} from '@angular/material/paginator';
import {AfterViewInit, ViewChild} from '@angular/core';
import { AuthService } from '../../core/auth.service';
import { finalize } from 'rxjs/operators'
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AppointmentService } from '../../services/appointment.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatSort } from '@angular/material/sort';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from 'app/core/config.service';

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-visithistorydata',
  templateUrl: './visithistorydata.component.html',
  styleUrls: ['./visithistorydata.component.css']
})
export class VisithistorydataComponent implements OnInit {

  public ob :Observable<Appointment[]>;  
  public dataSourceAppointmentData: Appointment[]= [];
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;  
  dtOptions: DataTables.Settings = {};  
  datasource: MatTableDataSource<Appointment>;
   displayedColumns = [
    'AppointmentId',
    'DoctorID',
    'DoctorName',
    'PatientID',
    'PatientName',
    'Date',
    'StartTime',
    'EndTime',
    'Description',
    'View_Edit_Delete'                                            
   ];
   
  public pIdToUpdate:number; 
  public aIdToUpdate:number; 
  public drName:string; 
  constructor(private authService: AuthService,
    private router: Router, private route: ActivatedRoute,
    private modalService: NgbModal,
    private appointmentsvc:AppointmentService,private spinner:NgxSpinnerService,private http:HttpClient,private conf:ConfigService ) { }

  ngOnInit(): void {
    this.LoadAppointmentsHistory();
    // const that = this;
    // this.dtOptions = {
      
    //   pagingType: 'full_numbers',
    //   pageLength: 2,
    //   serverSide: true,
    //   processing: true,
    //   ajax: (dataTablesParameters: any, callback) => {
    //     that.http.post<DataTablesResponse>(
    //         this.conf.tempResourseAPI+"/Doctor",
    //         dataTablesParameters, {}
    //       ).subscribe(resp => {
    //         //that.DoctorData = resp.data;

    //         callback({
    //           data: []
    //         });
    //       });
    //   },
    //   columns: [
    //   //   {
    //   //   title: 'Title',
    //   //   data: 'title'
    //   // }, {
    //   //   title: 'First name',
    //   //   data: 'firstname'
    //   // }, {
    //   //   title: 'Last name',
    //   //   data: 'lastname'
    //   // }, {
    //   //   title: 'Action',
    //   //   render: function (data: any, type: any, full: any) {
    //   //     return 'View';
    //   //   },
    //   // }
    // ]
    // };
  }

  public LoadAppointmentsHistory():void
  {    
    this.spinner.show();
    this.ob = this.appointmentsvc.GetAppointmentsHistoryForPatient(this.authService.email)
    this.ob.subscribe(
      data => { 
        this.spinner.hide();
        console.log("Output");
        console.log(data);
        this.datasource = new MatTableDataSource<Appointment>(data);
        this.datasource.paginator = this.paginator;
        this.datasource.sort = this.sort;
      },
      (error: any) => console.log("Error in fetching data")
      );
      
  }

  open(content,selectedaId?:number,selectedpId?:number,Drname?:string)
  { // Ng Pop Up Model    
    debugger;
    this.modalService.open(content,{ size:'xl',centered:true,scrollable:true});    
    this.aIdToUpdate=selectedaId;  
    this.pIdToUpdate=selectedpId;  
    this.drName=Drname; 
  }

}
