import { Component, OnInit } from '@angular/core';
import * as Chartist from 'chartist';
import { AuthService } from '../core/auth.service';
import { Observable } from 'rxjs';
import { Router,Navigation } from '@angular/router';
import { fromPromise } from 'rxjs/internal-compatibility';
import { NgxSpinnerService } from 'ngx-spinner';
import {DashboardService} from '../services/dashboard.service';
import {RegisterService} from '../services/register.service';
import {InboxService} from '../services/inbox.service';
import { finalize } from 'rxjs/operators';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  
  res:any;
  public ob :Observable<any>;
  //For Admin Dashboard
  public AdminDashBoardData;
  public doctorGraphData:any=[];
  public nurseGraphData:any=[];
  public patientGraphData:any=[];

  //For Doctor DashBoard
  public DoctorDashBoardData;
  public doctorPieChartData=[];

  //For Patient DashBoard
  public PatientDashBoardData;

   //For Nurse DashBoard
   public NurseDashBoardData;
  
  constructor(private auth: AuthService,private router:Router,private spinner:NgxSpinnerService
    ,private dashBoardService:DashboardService) { }
 
  startAnimationForBarChart(chart){
      let seq2: any, delays2: any, durations2: any;

      seq2 = 0;
      delays2 = 80;
      durations2 = 500;
      chart.on('draw', function(data) {
        if(data.type === 'bar'){
            seq2++;
            data.element.animate({
              opacity: {
                begin: seq2 * delays2,
                dur: durations2,
                from: 0,
                to: 1,
                easing: 'ease'
              }
            });
        }
      });

      seq2 = 0;
  };
  ngOnInit() {
    debugger;
      if(!this.auth.isAuthenticated()){
        this.router.navigate(["/login"]);
      }    
      this.initRole();  
    }

    initRole(){
      this.auth.getUserRole(this.auth.email)
        .pipe(finalize(() => {
        }))  
        .subscribe(
        result => {         
           if(result) {
              this.res = result;
              this.auth.userrole = this.res.role;
              this.InitializeDashBoardData();
           }
        },
        error => {
        });
    }

    InitializeDashBoardData(){
      debugger;
      if(this.auth.role=="admin")
      {
      this.LoadAdminDashBoard();
      }
      else if(this.auth.role=="doctor")
      {
        this.LoadDoctorDashBoard();
      }
      else if(this.auth.role=="patient")
      {
        this.LoadPatientDashBoard();
      }
      else if(this.auth.role=="nurse")
      {
        this.LoadNurseDashBoard();
      }
    }

    SetDoctorBarCharData(){
      /* ----------==========     Doctor Stats Chart initialization    ==========---------- */

      var datawebsiteViewsChart = {
        labels: ['Total', 'Active', 'InActive','Locked'],
        series: [
          this.doctorGraphData
        ],
        // distributeSeries: true
        
      };
      var optionswebsiteViewsChart = {  
          axisX: {
              showGrid: false
          },
          low: 0,
          high: (this.AdminDashBoardData.totalDoctors * 2),
          chartPadding: { top: 0, right: 5, bottom: 0, left: 0}
      };
      var responsiveOptions: any[] = [
        ['screen and (max-width: 640px)', {
          seriesBarDistance: 0,
          axisX: {
            labelInterpolationFnc: function (value) {
              return value[0];
            }
          }
        }]
      ];
      var websiteViewsChart = new Chartist.Bar('#doctorStatsChart', datawebsiteViewsChart, optionswebsiteViewsChart, responsiveOptions);

      //start animation for the Doctor Stats Chart
      this.startAnimationForBarChart(websiteViewsChart);
    }

    SetNurseBarCharData(){
      /* ----------==========     Nurse Stats Chart initialization    ==========---------- */

      var datawebsiteViewsChart = {
        labels: ['Total', 'Active', 'InActive','Locked'],
        series: [
          this.nurseGraphData
        ],
        // distributeSeries: true
        
      };
      var optionswebsiteViewsChart = {  
          axisX: {
              showGrid: false
          },
          low: 0,
          high: (this.AdminDashBoardData.totalNurses * 2),
          chartPadding: { top: 0, right: 5, bottom: 0, left: 0}
      };
      var responsiveOptions: any[] = [
        ['screen and (max-width: 640px)', {
          seriesBarDistance: 0,
          axisX: {
            labelInterpolationFnc: function (value) {
              return value[0];
            }
          }
        }]
      ];
      var websiteViewsChart = new Chartist.Bar('#nurseStatsChart', datawebsiteViewsChart, optionswebsiteViewsChart, responsiveOptions);

      //start animation for the Nurse Stats Chart
      this.startAnimationForBarChart(websiteViewsChart);
    }

    SetPatientBarCharData(){
      /* ----------==========     Patient Stats Chart initialization    ==========---------- */

      var datawebsiteViewsChart = {
        labels: ['Total', 'Active', 'InActive','Locked'],
        series: [
          this.patientGraphData
        ],
        // distributeSeries: true
        
      };
      var optionswebsiteViewsChart = {  
          axisX: {
              showGrid: false
          },
          low: 0,
          high: (this.AdminDashBoardData.totalPatients * 2),
          chartPadding: { top: 0, right: 5, bottom: 0, left: 0}
      };
      var responsiveOptions: any[] = [
        ['screen and (max-width: 640px)', {
          seriesBarDistance: 0,
          axisX: {
            labelInterpolationFnc: function (value) {
              return value[0];
            }
          }
        }]
      ];
      var websiteViewsChart = new Chartist.Bar('#patientStatsChart', datawebsiteViewsChart, optionswebsiteViewsChart, responsiveOptions);

      //start animation for the Patient Stats Chart
      this.startAnimationForBarChart(websiteViewsChart);
    }

    SetDoctorPieChartData(){
      var data = {
        labels: ['Approved', 'Rejected', 'Pending'],
        series: this.doctorPieChartData
      };
      
      var options = {
        labelInterpolationFnc: function(value) {
          return value[0]
        }
      };
      
      var responsiveOptions = [
        ['screen and (min-width: 640px)', {
          chartPadding: 30,
          labelOffset: 100,
          labelDirection: 'explode',
          labelInterpolationFnc: function(value) {
            return value;
          }
        }],
        ['screen and (min-width: 1024px)', {
          labelOffset: 80,
          chartPadding: 20
        }]
      ];
      
      new Chartist.Pie('#appointmentStatsChart', data, options);
    }

    public LoadAdminDashBoard():void
    { 
      debugger;
         this.spinner.show();    
         this.ob = this.dashBoardService.GetAdminDashBoardData();
         this.ob.subscribe(
         data => { 
          this.spinner.hide(); 
           debugger;
           console.log(data);
           this.AdminDashBoardData=data;
           console.log(this.AdminDashBoardData);
           console.log(this.AdminDashBoardData.totalDoctors);
           this.doctorGraphData.push(this.AdminDashBoardData.totalDoctors);
           this.doctorGraphData.push(this.AdminDashBoardData.totalActiveDoctors);
           this.doctorGraphData.push(this.AdminDashBoardData.totalInActiveDoctors);
           this.doctorGraphData.push(this.AdminDashBoardData.totalLockedDoctors);

           this.nurseGraphData.push(this.AdminDashBoardData.totalNurses);
           this.nurseGraphData.push(this.AdminDashBoardData.totalActiveNurses);
           this.nurseGraphData.push(this.AdminDashBoardData.totalInActiveNurses);
           this.nurseGraphData.push(this.AdminDashBoardData.totalLockedPatients);

           this.patientGraphData.push(this.AdminDashBoardData.totalPatients);
           this.patientGraphData.push(this.AdminDashBoardData.totalActivePatients);
           this.patientGraphData.push(this.AdminDashBoardData.totalInActivePatients);
           this.patientGraphData.push(this.AdminDashBoardData.totalLockedNurses);

           this.SetDoctorBarCharData();
           this.SetNurseBarCharData();
           this.SetPatientBarCharData();
        },
        (error: any) => console.log("Error in fetching data")
        );
    }

    public LoadDoctorDashBoard():void
    { 
      debugger;
         this.spinner.show();    
         this.ob = this.dashBoardService.GetDoctorDashBoardData(this.auth.email);
         this.ob.subscribe(
         data => { 
          this.spinner.hide(); 
           debugger;
           console.log(data);
           this.DoctorDashBoardData=data;
           this.doctorPieChartData.push(this.DoctorDashBoardData.totalApproved);
           this.doctorPieChartData.push(this.DoctorDashBoardData.totalRejected);
           this.doctorPieChartData.push(this.DoctorDashBoardData.totalPending);
           this.SetDoctorPieChartData();
        },
        (error: any) => console.log("Error in fetching data")
        );
    }

    public LoadPatientDashBoard():void
    { 
      debugger;
         this.spinner.show();    
         this.ob = this.dashBoardService.GetPatientDashBoardData(this.auth.email);
         this.ob.subscribe(
         data => { 
          this.spinner.hide(); 
           debugger;
           console.log(data);
           this.PatientDashBoardData=data;
        },
        (error: any) => console.log("Error in fetching data")
        );
    }

    public LoadNurseDashBoard():void
    { 
      debugger;
         this.spinner.show();    
         this.ob = this.dashBoardService.GetNurseDashBoardData();
         this.ob.subscribe(
         data => { 
          this.spinner.hide(); 
           debugger;
           console.log(data);
           this.NurseDashBoardData=data;
        },
        (error: any) => console.log("Error in fetching data")
        );
    }
}
