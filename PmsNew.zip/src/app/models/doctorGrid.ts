export class doctorGrid{
    doctorDisplayId: string;
    isActive: boolean;
    firstName: string;
    lastName: string;
    emailId: string;
    Name: string;
    Dob:string;
    age:number;
    gender:string;
    isLocked:boolean;
  }