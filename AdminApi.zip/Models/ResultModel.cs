﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminApi.Models
{
	public class ResultModel
	{
		public int Code { get; set; }
		public string Response { get; set; }
	}
}
