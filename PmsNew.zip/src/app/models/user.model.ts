export class UserModel{
    email: string;
    oldPassword: string;
    newPassword: string;
        confirmPassword:string;
    constructor(
        email:string,
        oldPassword: string,
        newPassword: string,
        confirmPassword:string,
    ){}
    // get email() { return this.email };
    // set email(email: string) { this.email = email };
    // get oldPassword() { return this.oldPassword };
    // set oldPassword(email: string) { this.oldPassword = email };
    // get newPassword() { return this.newPassword };
    // set newPassword(email: string) { this.newPassword = email };
    // get confirmPassword() { return this.confirmPassword };
    // set confirmPassword(email: string) { this.confirmPassword = email };
    
}