﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InboxManagementServer.Models;
using InboxManagementServer.Services;
using Moq;
using Microsoft.AspNetCore.Mvc;

namespace InboxNUnitTestProject.Tests
{
    class InboxControllerTests
    {
        private Mock<IInboxRepository> iInboxRepository;
        private List<CalendarNotification> lstCalendarNotification;
        private AppointmentDetails appointmentDetails;
        [SetUp]
        public void Setup()
        {
            iInboxRepository = new Mock<IInboxRepository>();
            //CalendarNotification List
            lstCalendarNotification = new List<CalendarNotification>();
            lstCalendarNotification.Add(new CalendarNotification()
            {
                   id= 4,title= "for Strong Fever and Headache",date= "2021-03-17",textColor= "white",backgroundColor= "yellow",start= "2021-03-17T20:26:00",end= "2021-03-17T21:26:00"
            });
            lstCalendarNotification.Add(new CalendarNotification()
            {
                id = 5,
                title = "for Strong Fever and Headache",
                date = "2021-03-17",
                textColor = "white",
                backgroundColor = "yellow",
                start = "2021-03-17T20:26:00",
                end = "2021-03-17T21:26:00"
            });
            lstCalendarNotification.Add(new CalendarNotification()
            {
                id = 6,
                title = "for Strong Fever and Headache",
                date = "2021-03-17",
                textColor = "white",
                backgroundColor = "yellow",
                start = "2021-03-17T20:26:00",
                end = "2021-03-17T21:26:00"
            });

            //AppointmentDetails Data
            appointmentDetails = new AppointmentDetails()
            {
               id= 4,patientId= "PT-0006",patientName= "vivek patil",date= "3/17/2021",startTime= "8:26 PM",endTime= "9:26 PM",
               description= "for Strong Fever and Headache",status= "Pending",reason= "sdsadsdsd"
            };
        }

        [Test]
        public void TestForGetAllCalendarNotifications()
        {
            iInboxRepository.Setup(x => x.GetAllCalendarNotifications("doctor", "vp@gmail.com")).Returns(lstCalendarNotification.ToList());

            var inboxController = new InboxManagementServer.Controllers.InboxController(iInboxRepository.Object);
            var lstAllCalenderNotifications = inboxController.GetAllCalendarNotifications("doctor", "vp@gmail.com");
            var result = lstAllCalenderNotifications as OkObjectResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);

            var data = result.Value as List<CalendarNotification>;
            Assert.AreEqual(3, data.Count);
        }

        [Test]
        public void TestForGetAppointmentDeatils()
        {
            iInboxRepository.Setup(x => x.GetAppointmentDeatils(4)).Returns(appointmentDetails);

            var inboxController = new InboxManagementServer.Controllers.InboxController(iInboxRepository.Object);
            var appointmentDetailsData = inboxController.GetAppointmentsDetails(4);
            var result = appointmentDetailsData as OkObjectResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);

            var data = result.Value as AppointmentDetails;
            Assert.AreEqual("PT-0006", data.patientId);
        }
    }
}
