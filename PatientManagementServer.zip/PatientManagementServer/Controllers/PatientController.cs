﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PatientManagementServer.Services;
using PatientManagementServer.Models;
using Microsoft.AspNetCore.Cors;
using System.Text;
using System.IO;
using CsvHelper;
using CsvHelper.Configuration;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using System.Data;
using Newtonsoft.Json;

namespace PatientManagementServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[DisableCors]
    [SecurityHeaders]
    public class PatientController : ControllerBase
    {
        private IPatientRepository _patientRepository;
        public PatientController(IPatientRepository patientRepository)
        {
            this._patientRepository = patientRepository;
        }


        /// <summary>
        /// To get patient demographic data
        /// </summary>
        [HttpGet("getdemographic")]
        public IActionResult GetDemographicData(string userName)
        {
            DemographicData data = new DemographicData();
            try
            {
                ResultModel res = new ResultModel();
                if (userName == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientRepository.GetDemographicById(userName);
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To get patient allergy data
        /// </summary>
        [HttpGet("getallergy")]
        public IActionResult GetAllergyData(string userName)
        {
            List<AllergyModel> allergyModels = new List<AllergyModel>();
            try
            {
                ResultModel res = new ResultModel();
                if (userName == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    allergyModels = _patientRepository.GetAllergyById(userName);
                    return Ok(allergyModels);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To get patient data
        /// </summary>
        [HttpGet("getpatient")]
        public IActionResult GetPatientData(string userName)
        {
            PatientMaster data = new PatientMaster();
            try
            {
                ResultModel res = new ResultModel();
                if (userName == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientRepository.GetPatientById(userName);
                    return Ok(new { firstname = data.FirstName, lastname = data.LastName, dob = data.Dob, contact = data.ContactNumber, email = data.EmailId });
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To get allergy data
        /// </summary>
        [HttpGet("getallergydata")]
        public IActionResult GetAllergyData()
        {
            List<AllergyMaster> data = new List<AllergyMaster>();
            try
            {
                data = _patientRepository.GetAllergyMasterData();
                return Ok(data);
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }


        /// <summary>
        /// To save patient demographic data
        /// </summary>
        [HttpPost("adddemographic")]
        public IActionResult AddDemographicData(string userName, DemographicData demographicData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (demographicData == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientRepository.AddPatientDemographicData(userName, demographicData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To Update patient demographic data
        /// </summary>
        [HttpPatch("updatedemographic")]
        public IActionResult UpdateDemographicData(string userName, DemographicData demographicData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (demographicData == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientRepository.AddPatientDemographicData(userName, demographicData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }


        /// <summary>
        /// To save patient allergy data
        /// </summary>
        [HttpPost("addallergy")]
        public IActionResult AddAllergyData(string userName, AllergyModel allergyModel)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (allergyModel == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientRepository.AddPatientAllergy(userName, allergyModel);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To get notification data
        /// </summary>
        [HttpGet("getnotifications")]
        public IActionResult GetNotifications(string userName)
        {
            List<NotificationModel> data = new List<NotificationModel>();
            try
            {
                if (userName == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientRepository.GetNotifications(userName);
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To save Notification data
        /// </summary>
        [HttpPatch("updatenotification")]
        /// <summary>
        /// To update notification data
        /// </summary>
        public IActionResult UpdateNotification(int id)
        {
            try
            {
                if (id <= 0)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    _patientRepository.UpdateNotification(id);
                    return Ok();
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }


        ///// <summary>
        ///// To download csv file
        ///// </summary>
        //[HttpGet("getcsv")]
        //public IActionResult DownloadCommaSeperatedFile(string userName)
        //{
        //    try
        //    {
        //        StringBuilder stringBuilder = new StringBuilder();
        //        DemographicData data = new DemographicData();
        //        data = _patientRepository.GetDemographicById(userName);
        //        List<DemographicData> dem = new List<DemographicData>();
        //        dem.Add(data);

        //        if (data != null)
        //        {
        //            var stream = new MemoryStream();
        //            var cc = new CsvConfiguration(new System.Globalization.CultureInfo("en-US"));
        //            using (var writeFile = new StreamWriter(stream, leaveOpen: true))
        //            {
        //                var csv = new CsvWriter(writeFile, cc);
        //                csv.WriteRecords(dem);
        //            }
        //            stream.Position = 0; //reset stream
        //            //string fileName = "Report_" + DateTime.Now+".csv";
        //            return File(stream, "application/csv", "Report.csv");
        //        }
        //        else
        //        {
        //            return BadRequest();
        //        }
        //    }
        //    catch
        //    {
        //        return BadRequest();
        //    }
        //}

        ///// <summary>
        ///// To download excel file
        ///// </summary>
        //[HttpGet("getexcel")]
        //public IActionResult DownloadExcelFile(string userName)
        //{
        //    try
        //    {
        //        StringBuilder stringBuilder = new StringBuilder();
        //        DemographicData data = new DemographicData();
        //        data = _patientRepository.GetDemographicById(userName);
        //        List<DemographicData> dem = new List<DemographicData>();
        //        dem.Add(data);

        //        if (data != null)
        //        {
        //            using (MemoryStream mem = new MemoryStream())
        //            {
        //                // Create a spreadsheet document by supplying the filepath.
        //                // By default, AutoSave = true, Editable = true, and Type = xlsx.
        //                SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.
        //            Create(mem, SpreadsheetDocumentType.Workbook);

        //                WorkbookPart workbookPart = spreadsheetDocument.AddWorkbookPart();
        //                workbookPart.Workbook = new Workbook();

        //                WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
        //                var sheetData = new SheetData();
        //                worksheetPart.Worksheet = new Worksheet(sheetData);

        //                WorkbookStylesPart stylesPart = spreadsheetDocument.WorkbookPart.AddNewPart<WorkbookStylesPart>();
        //                stylesPart.Stylesheet = GenerateStyleSheet();
        //                stylesPart.Stylesheet.Save();

        //                Sheets sheets = workbookPart.Workbook.AppendChild(new Sheets());
        //                Sheet sheet = new Sheet() { Id = workbookPart.GetIdOfPart(worksheetPart), SheetId = 1, Name = "Sheet1" };

        //                sheets.Append(sheet);

        //                MergeCells mergeCells = new MergeCells();

        //                DocumentFormat.OpenXml.Spreadsheet.Row headerRow = new DocumentFormat.OpenXml.Spreadsheet.Row();
        //                List<AllergyModel> allergyModels = new List<AllergyModel>();
        //                allergyModels = _patientRepository.GetAllergyById(userName);
        //                ListtoDataTableConverter converter = new ListtoDataTableConverter();
        //                DataTable allergyTable = converter.ToDataTable(allergyModels);
        //                List<String> columns = new List<string> { "allergy", "isfatal" };
        //                foreach (string str in columns)
        //                {
        //                    DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { StyleIndex = 4 };
        //                    //cell=AddToCell()
        //                    cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
        //                    cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(str);
        //                    headerRow.AppendChild(cell);
        //                }
        //                sheetData.AppendChild(headerRow);

        //                foreach (DataRow item in allergyTable.Rows)
        //                {
        //                    DocumentFormat.OpenXml.Spreadsheet.Row newRow = new DocumentFormat.OpenXml.Spreadsheet.Row();
        //                    foreach (String col in columns)
        //                    {
        //                        DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();
        //                        cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
        //                        cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(item[col].ToString());
        //                        newRow.AppendChild(cell);
        //                    }
        //                    sheetData.AppendChild(newRow);
        //                }


        //                //append a MergeCell to the mergeCells for each set of merged cells
        //                //mergeCells.Append(new MergeCell() { Reference = new StringValue("C1:F1") });

        //                //worksheetPart.Worksheet.InsertAfter(mergeCells, worksheetPart.Worksheet.Elements<SheetData>().First());

        //                workbookPart.Workbook.Save();

        //                // Close the document.
        //                spreadsheetDocument.Close();
        //                return File(mem.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Report.xlsx");
        //                //return File(mem.ToArray(), "application/octet-stream","Report.xlsx");
        //            }
        //        }
        //        else
        //        {
        //            return BadRequest();
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        return BadRequest();
        //    }
        //}

        //public static Stylesheet GenerateStyleSheet()
        //{
        //    return new Stylesheet(
        //    new DocumentFormat.OpenXml.Spreadsheet.Fonts(
        //    new DocumentFormat.OpenXml.Spreadsheet.Font(new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),// Index 0 - The default font.
        //    new Font(new Bold(), new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 1 - The bold font.
        //    new Font(new Italic(), new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 2 - The Italic font.
        //    new Font(new FontSize() { Val = 18 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 3 - The Times Roman font. with 16 size
        //    new Font(new Bold(), new FontSize() { Val = 18 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 4 - The Times Roman font. with 16 size
        //    new Font(new Bold(), new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "FFFFFF" } }, new FontName() { Val = "Calibri" })  // Index 5 - The bold font.

        //    ),
        //    new Fills(
        //    new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 0 - The default fill.
        //    new DocumentFormat.OpenXml.Spreadsheet.PatternFill() { PatternType = PatternValues.None }),
        //    new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 1 - The default fill of gray 125 (required)
        //    new DocumentFormat.OpenXml.Spreadsheet.PatternFill() { PatternType = PatternValues.Gray125 }),
        //    new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 2 - The yellow fill.
        //    new DocumentFormat.OpenXml.Spreadsheet.PatternFill(
        //    new DocumentFormat.OpenXml.Spreadsheet.ForegroundColor() { Rgb = new HexBinaryValue() { Value = "D3D3D3" } }
        //    )
        //    { PatternType = PatternValues.Solid }),
        //    new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 3 - The Blue fill.
        //    new DocumentFormat.OpenXml.Spreadsheet.PatternFill(
        //    new DocumentFormat.OpenXml.Spreadsheet.ForegroundColor() { Rgb = new HexBinaryValue() { Value = "8EA9DB" } }
        //    )
        //    { PatternType = PatternValues.Solid })
        //    ),
        //    new Borders(
        //    new Border( // Index 0 - The default border.
        //    new DocumentFormat.OpenXml.Spreadsheet.LeftBorder(),
        //    new DocumentFormat.OpenXml.Spreadsheet.RightBorder(),
        //    new DocumentFormat.OpenXml.Spreadsheet.TopBorder(),
        //    new DocumentFormat.OpenXml.Spreadsheet.BottomBorder(),
        //    new DiagonalBorder()),
        //    new Border( // Index 1 - Applies a Left, Right, Top, Bottom border to a cell
        //    new DocumentFormat.OpenXml.Spreadsheet.LeftBorder(
        //    new Color() { Auto = true }
        //    )
        //    { Style = BorderStyleValues.Thin },
        //    new DocumentFormat.OpenXml.Spreadsheet.RightBorder(
        //    new Color() { Auto = true }
        //    )
        //    { Style = BorderStyleValues.Thin },
        //    new DocumentFormat.OpenXml.Spreadsheet.TopBorder(
        //    new Color() { Auto = true }
        //    )
        //    { Style = BorderStyleValues.Thin },
        //    new DocumentFormat.OpenXml.Spreadsheet.BottomBorder(
        //    new Color() { Auto = true }
        //    )
        //    { Style = BorderStyleValues.Thin },
        //    new DiagonalBorder()),
        //           new Border( // Index 1 - Applies a Left, Right, Top, Bottom border to a cell
        //    new DocumentFormat.OpenXml.Spreadsheet.LeftBorder(
        //    new Color() { Auto = true }
        //    )
        //    { Style = BorderStyleValues.None },
        //    new DocumentFormat.OpenXml.Spreadsheet.RightBorder(
        //    new Color() { Auto = true }
        //    )
        //    { Style = BorderStyleValues.None },
        //    new DocumentFormat.OpenXml.Spreadsheet.TopBorder(
        //    new Color() { Auto = true }
        //    )
        //    { Style = BorderStyleValues.None },
        //    new DocumentFormat.OpenXml.Spreadsheet.BottomBorder(
        //    new Color() { Rgb = new HexBinaryValue() { Value = "FFA500" } }
        //    )
        //    { Style = BorderStyleValues.Thin },
        //    new DiagonalBorder())
        //    ),
        //    new CellFormats(
        //    new CellFormat() { FontId = 0, FillId = 0, BorderId = 0 }, // Index 0 - The default cell style. If a cell does not have a style index applied it will use this style combination instead
        //    new CellFormat() { FontId = 1, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 1 - Bold
        //    new CellFormat() { FontId = 2, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 2 - Italic
        //    new CellFormat() { FontId = 3, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 3 - Times Roman
        //    new CellFormat() { FontId = 0, FillId = 2, BorderId = 1, ApplyFill = true }, // Index 4 - Yellow Fill
        //    new CellFormat( // Index 5 - Alignment
        //    new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }
        //    )
        //    { FontId = 0, FillId = 0, BorderId = 0, ApplyAlignment = true },
        //    new CellFormat() { FontId = 0, FillId = 0, BorderId = 1, ApplyBorder = true }, // Index 6 - Border
        //     new CellFormat(new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }) // Index 7 - Alignment
        //     { FontId = 1, FillId = 0, BorderId = 0, ApplyAlignment = true },

        //     new CellFormat() { FontId = 4, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 8 - Times Roman
        //     new CellFormat(new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }) { FontId = 0, FillId = 0, BorderId = 2, ApplyFont = true }, // Index 9 - Bottom Border with Color 70AD47
        //     new CellFormat(new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }) // Index 10 - Alignment
        //     { FontId = 5, FillId = 3, BorderId = 0, ApplyAlignment = true }


        //     )
        //    ); // return
        //}
    }
}
