import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { observable, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ConfigService } from '../core/config.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private httpsvc:HttpClient, private config:ConfigService) { }
  
  public GetAdminDashBoardData():Observable<any>
  {
   let header = new HttpHeaders({
     'Content-Type': 'application/json'
    });
      return this.httpsvc.get(this.config.adminApiUri+"/getadmindashboarddata",{headers:header});      
  }

  public GetDoctorDashBoardData(userName:string):Observable<any>
  {
   let header = new HttpHeaders({
     'Content-Type': 'application/json'
    });
      return this.httpsvc.get(this.config.adminApiUri+"/getdoctordashboarddata?userName="+userName,{headers:header});      
  }

  public GetPatientDashBoardData(userName:string):Observable<any>
  {
   let header = new HttpHeaders({
     'Content-Type': 'application/json'
    });
      return this.httpsvc.get(this.config.adminApiUri+"/getpatientdashboarddata?userName="+userName,{headers:header});      
  }

  public GetNurseDashBoardData():Observable<any>
  {
   let header = new HttpHeaders({
     'Content-Type': 'application/json'
    });
      return this.httpsvc.get(this.config.adminApiUri+"/getnursedashboarddata",{headers:header});      
  }
}
