﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
using PatientVisitMangementServer.Models;
using PatientVisitMangementServer.Services;
using PatientVisitMangementServer.Data.AppDbContext;

namespace PatientVisitMangementServer.Services
{
    public class ListtoDataTableConverter
    {
        //PMSYSTEMContext _dbContext = new PMSYSTEMContext();
        //IPatientVisitRepository _patientVisitRepository;
        //PatientVisitDbRepository patientVisit = new PatientVisitDbRepository(_dbContext);

        private IPatientVisitRepository _patientVisitRepository;
        public ListtoDataTableConverter(IPatientVisitRepository patientVisitRepository)
        {
            this._patientVisitRepository = patientVisitRepository;
        }

            public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public MemoryStream CreateExcel(int appointmentId, int patientId)
        {

            using (MemoryStream mem = new MemoryStream())
            {
                // Create a spreadsheet document by supplying the filepath.
                // By default, AutoSave = true, Editable = true, and Type = xlsx.
                SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.
            Create(mem, SpreadsheetDocumentType.Workbook);

                WorkbookPart workbookPart = spreadsheetDocument.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
                var sheetData = new SheetData();
                worksheetPart.Worksheet = new Worksheet(sheetData);

                WorkbookStylesPart stylesPart = spreadsheetDocument.WorkbookPart.AddNewPart<WorkbookStylesPart>();
                stylesPart.Stylesheet = GenerateStyleSheet();
                stylesPart.Stylesheet.Save();

                Sheets sheets = workbookPart.Workbook.AppendChild(new Sheets());
                Sheet sheet = new Sheet() { Id = workbookPart.GetIdOfPart(worksheetPart), SheetId = 1, Name = "Visit Details" };

                sheets.Append(sheet);
                List<String> columns = new List<string>();
                #region Appointment Data
                DocumentFormat.OpenXml.Spreadsheet.Row sectionheader = new DocumentFormat.OpenXml.Spreadsheet.Row();
                List<ViewAppointments> viewAppointments = new List<ViewAppointments>();
                viewAppointments = _patientVisitRepository.GetAppointmentsHistoryForPatient(appointmentId);
                DataTable appointmentDataTable = ToDataTable(viewAppointments);
                columns = new List<string> { "patientname", "drname", "date", "description"};
                
                foreach (DataRow item in appointmentDataTable.Rows)
                {
                    
                    foreach (String col in columns)
                    {
                        DocumentFormat.OpenXml.Spreadsheet.Row sectionData = new DocumentFormat.OpenXml.Spreadsheet.Row();
                        DocumentFormat.OpenXml.Spreadsheet.Cell cell1 = new DocumentFormat.OpenXml.Spreadsheet.Cell() { StyleIndex = 4 };
                        cell1.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell1.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(col.ToUpper());
                        sectionData.AppendChild(cell1);

                        DocumentFormat.OpenXml.Spreadsheet.Cell cell2 = new DocumentFormat.OpenXml.Spreadsheet.Cell();
                        cell2.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell2.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(item[col].ToString());
                        sectionData.AppendChild(cell2);

                        sheetData.AppendChild(sectionData);
                    }
                    sheetData.AppendChild(new Row());
                }

                #endregion

                #region Vital Stats
                DocumentFormat.OpenXml.Spreadsheet.Row section0header = new DocumentFormat.OpenXml.Spreadsheet.Row();
                List<PatientVitalSign> lstPatientVitalSign = new List<PatientVitalSign>();
                PatientVitalSign patientVitalSign = _patientVisitRepository.GetPatientVitalSignByAppointmentId(appointmentId);
                lstPatientVitalSign.Add(patientVitalSign);
                DataTable vitalStatTable = ToDataTable(lstPatientVitalSign);
                 columns = new List<string> { "Height", "Weight","BloodPressureSystolic", "BloodPressureDiastolic","BodyTemperature","RespirationRate"};
                foreach (string str in columns)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { StyleIndex = 4 };
                    //cell=AddToCell()
                    cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                    cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(str.ToUpper());
                    section0header.AppendChild(cell);
                }
                sheetData.AppendChild(section0header);

                foreach (DataRow item in vitalStatTable.Rows)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Row section0Data = new DocumentFormat.OpenXml.Spreadsheet.Row();
                    foreach (String col in columns)
                    {
                        DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();
                        cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(item[col].ToString());
                        section0Data.AppendChild(cell);
                    }
                    sheetData.AppendChild(section0Data);
                }
                sheetData.AppendChild(new Row());

                #endregion

                #region Allergy
                DocumentFormat.OpenXml.Spreadsheet.Row section1header = new DocumentFormat.OpenXml.Spreadsheet.Row();
                List<PatientAllergyVisit> allergyModels = new List<PatientAllergyVisit>();
                allergyModels = _patientVisitRepository.GetPatientAllergyByPatientId(patientId);
                DataTable allergyTable = ToDataTable(allergyModels);
                 columns = new List<string> { "AllergyName", "FatalAllergy" };
                foreach (string str in columns)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { StyleIndex = 4 };
                    //cell=AddToCell()
                    cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                    cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(str.ToUpper());
                    section1header.AppendChild(cell);
                }
                sheetData.AppendChild(section1header);

                foreach (DataRow item in allergyTable.Rows)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Row section1Data = new DocumentFormat.OpenXml.Spreadsheet.Row();
                    foreach (String col in columns)
                    {
                        DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();
                        cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(item[col].ToString());
                        section1Data.AppendChild(cell);
                    }
                    sheetData.AppendChild(section1Data);
                }
                sheetData.AppendChild(new Row());

                #endregion

                #region Diagnosis
                DocumentFormat.OpenXml.Spreadsheet.Row section2header = new DocumentFormat.OpenXml.Spreadsheet.Row();
                List<PatientDiagnosis> patientDiagnoses = new List<PatientDiagnosis>();
                patientDiagnoses = _patientVisitRepository.GetPatientDiagnosisByAppointmentId(appointmentId);
                DataTable diagnosisTable = ToDataTable(patientDiagnoses);
                columns = new List<string> { "DiagnosisCode", "DiagnosisDescription" };
                foreach (string str in columns)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { StyleIndex = 4 };
                    //cell=AddToCell()
                    cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                    cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(str.ToUpper());
                    section2header.AppendChild(cell);
                }
                sheetData.AppendChild(section2header);

                foreach (DataRow item in diagnosisTable.Rows)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Row section2Data = new DocumentFormat.OpenXml.Spreadsheet.Row();
                    foreach (String col in columns)
                    {
                        DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();
                        cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(item[col].ToString());
                        section2Data.AppendChild(cell);
                    }
                    sheetData.AppendChild(section2Data);
                }
                sheetData.AppendChild(new Row());

                #endregion

                #region Medication
                DocumentFormat.OpenXml.Spreadsheet.Row section3header = new DocumentFormat.OpenXml.Spreadsheet.Row();
                List<PatientMedication> patientMedications = new List<PatientMedication>();
                patientMedications = _patientVisitRepository.GetPatientMedicationByAppointmentId(appointmentId);
                DataTable medicationTable = ToDataTable(patientMedications);
                columns = new List<string> { "MedicineStrength", "Description" };
                foreach (string str in columns)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { StyleIndex = 4 };
                    //cell=AddToCell()
                    cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                    cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(str.ToUpper());
                    section3header.AppendChild(cell);
                }
                sheetData.AppendChild(section3header);

                foreach (DataRow item in medicationTable.Rows)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Row section3Data = new DocumentFormat.OpenXml.Spreadsheet.Row();
                    foreach (String col in columns)
                    {
                        DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();
                        cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(item[col].ToString());
                        section3Data.AppendChild(cell);
                    }
                    sheetData.AppendChild(section3Data);
                }
                sheetData.AppendChild(new Row());

                #endregion

                #region Procedure
                DocumentFormat.OpenXml.Spreadsheet.Row section4header = new DocumentFormat.OpenXml.Spreadsheet.Row();
                List<PatientProcedure> patientProcedures = new List<PatientProcedure>();
                patientProcedures = _patientVisitRepository.GetPatientProcedureByAppointmentId(appointmentId);
                DataTable procedureTable = ToDataTable(patientProcedures);
                columns = new List<string> { "ProcedureCode", "ProcedureDescription" };
                foreach (string str in columns)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { StyleIndex = 4 };
                    //cell=AddToCell()
                    cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                    cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(str.ToUpper());
                    section4header.AppendChild(cell);
                }
                sheetData.AppendChild(section4header);

                foreach (DataRow item in procedureTable.Rows)
                {
                    DocumentFormat.OpenXml.Spreadsheet.Row section4Data = new DocumentFormat.OpenXml.Spreadsheet.Row();
                    foreach (String col in columns)
                    {
                        DocumentFormat.OpenXml.Spreadsheet.Cell cell = new DocumentFormat.OpenXml.Spreadsheet.Cell();
                        cell.DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
                        cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(item[col].ToString());
                        section4Data.AppendChild(cell);
                    }
                    sheetData.AppendChild(section4Data);
                }
                sheetData.AppendChild(new Row());

                #endregion 

                workbookPart.Workbook.Save();

                // Close the document.
                spreadsheetDocument.Close();
                return mem;
            }
        }

        public static Stylesheet GenerateStyleSheet()
        {
            return new Stylesheet(
            new DocumentFormat.OpenXml.Spreadsheet.Fonts(
            new DocumentFormat.OpenXml.Spreadsheet.Font(new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),// Index 0 - The default font.
            new Font(new Bold(), new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 1 - The bold font.
            new Font(new Italic(), new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 2 - The Italic font.
            new Font(new FontSize() { Val = 18 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 3 - The Times Roman font. with 16 size
            new Font(new Bold(), new FontSize() { Val = 18 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }),  // Index 4 - The Times Roman font. with 16 size
            new Font(new Bold(), new FontSize() { Val = 11 }, new Color() { Rgb = new HexBinaryValue() { Value = "FFFFFF" } }, new FontName() { Val = "Calibri" })  // Index 5 - The bold font.

            ),
            new Fills(
            new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 0 - The default fill.
            new DocumentFormat.OpenXml.Spreadsheet.PatternFill() { PatternType = PatternValues.None }),
            new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 1 - The default fill of gray 125 (required)
            new DocumentFormat.OpenXml.Spreadsheet.PatternFill() { PatternType = PatternValues.Gray125 }),
            new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 2 - The yellow fill.
            new DocumentFormat.OpenXml.Spreadsheet.PatternFill(
            new DocumentFormat.OpenXml.Spreadsheet.ForegroundColor() { Rgb = new HexBinaryValue() { Value = "D3D3D3" } }
            )
            { PatternType = PatternValues.Solid }),
            new DocumentFormat.OpenXml.Spreadsheet.Fill( // Index 3 - The Blue fill.
            new DocumentFormat.OpenXml.Spreadsheet.PatternFill(
            new DocumentFormat.OpenXml.Spreadsheet.ForegroundColor() { Rgb = new HexBinaryValue() { Value = "8EA9DB" } }
            )
            { PatternType = PatternValues.Solid })
            ),
            new Borders(
            new Border( // Index 0 - The default border.
            new DocumentFormat.OpenXml.Spreadsheet.LeftBorder(),
            new DocumentFormat.OpenXml.Spreadsheet.RightBorder(),
            new DocumentFormat.OpenXml.Spreadsheet.TopBorder(),
            new DocumentFormat.OpenXml.Spreadsheet.BottomBorder(),
            new DiagonalBorder()),
            new Border( // Index 1 - Applies a Left, Right, Top, Bottom border to a cell
            new DocumentFormat.OpenXml.Spreadsheet.LeftBorder(
            new Color() { Auto = true }
            )
            { Style = BorderStyleValues.Thin },
            new DocumentFormat.OpenXml.Spreadsheet.RightBorder(
            new Color() { Auto = true }
            )
            { Style = BorderStyleValues.Thin },
            new DocumentFormat.OpenXml.Spreadsheet.TopBorder(
            new Color() { Auto = true }
            )
            { Style = BorderStyleValues.Thin },
            new DocumentFormat.OpenXml.Spreadsheet.BottomBorder(
            new Color() { Auto = true }
            )
            { Style = BorderStyleValues.Thin },
            new DiagonalBorder()),
                   new Border( // Index 1 - Applies a Left, Right, Top, Bottom border to a cell
            new DocumentFormat.OpenXml.Spreadsheet.LeftBorder(
            new Color() { Auto = true }
            )
            { Style = BorderStyleValues.None },
            new DocumentFormat.OpenXml.Spreadsheet.RightBorder(
            new Color() { Auto = true }
            )
            { Style = BorderStyleValues.None },
            new DocumentFormat.OpenXml.Spreadsheet.TopBorder(
            new Color() { Auto = true }
            )
            { Style = BorderStyleValues.None },
            new DocumentFormat.OpenXml.Spreadsheet.BottomBorder(
            new Color() { Rgb = new HexBinaryValue() { Value = "FFA500" } }
            )
            { Style = BorderStyleValues.Thin },
            new DiagonalBorder())
            ),
            new CellFormats(
            new CellFormat() { FontId = 0, FillId = 0, BorderId = 0 }, // Index 0 - The default cell style. If a cell does not have a style index applied it will use this style combination instead
            new CellFormat() { FontId = 1, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 1 - Bold
            new CellFormat() { FontId = 2, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 2 - Italic
            new CellFormat() { FontId = 3, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 3 - Times Roman
            new CellFormat() { FontId = 0, FillId = 2, BorderId = 1, ApplyFill = true }, // Index 4 - Light Gray Fill
            new CellFormat( // Index 5 - Alignment
            new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }
            )
            { FontId = 0, FillId = 0, BorderId = 0, ApplyAlignment = true },
            new CellFormat() { FontId = 0, FillId = 0, BorderId = 1, ApplyBorder = true }, // Index 6 - Border
             new CellFormat(new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }) // Index 7 - Alignment
             { FontId = 1, FillId = 0, BorderId = 0, ApplyAlignment = true },

             new CellFormat() { FontId = 4, FillId = 0, BorderId = 0, ApplyFont = true }, // Index 8 - Times Roman
             new CellFormat(new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }) { FontId = 0, FillId = 0, BorderId = 2, ApplyFont = true }, // Index 9 - Bottom Border with Color 70AD47
             new CellFormat(new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }) // Index 10 - Alignment
             { FontId = 5, FillId = 3, BorderId = 0, ApplyAlignment = true }


             )
            ); // return
        }
    }
}
