﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientVisitMangementServer.Services
{
    public class PatientAllergyVisit
    {
        public int PatientId { get; set; }
        public int AllergyId { get; set; }
        public string AllergyName { get; set; }
        public bool FatalAllergy { get; set; }
    }
}
