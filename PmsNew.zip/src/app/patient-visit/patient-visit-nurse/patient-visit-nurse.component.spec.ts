import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientVisitNurseComponent } from './patient-visit-nurse.component';

describe('PatientVisitNurseComponent', () => {
  let component: PatientVisitNurseComponent;
  let fixture: ComponentFixture<PatientVisitNurseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientVisitNurseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientVisitNurseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
