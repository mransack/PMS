﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PatientVisitMangementServer.Services;
using PatientVisitMangementServer.Models;
using Microsoft.AspNetCore.Cors;
using System.IO;

namespace PatientVisitMangementServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [SecurityHeaders]
    public class PatientVisitController : ControllerBase
    {
        private IPatientVisitRepository _patientVisitRepository;
        public PatientVisitController(IPatientVisitRepository patientVisitRepository)
        {
            this._patientVisitRepository = patientVisitRepository;
        }
        /// <summary>
        /// To save patient vital signs data
        /// </summary>
        [HttpPost("addvitalsigns")]
        public IActionResult AddVitalSignsData(PatientVitalSign patientVitalSignData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (patientVitalSignData.AppointmentId == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientVisitRepository.AddPatientVitalSignData(patientVitalSignData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To save patient vital signs data
        /// </summary>
        [HttpPost("updatevitalsigns")]
        public IActionResult UpdateVitalSignsData(PatientVitalSign patientVitalSignData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (patientVitalSignData.AppointmentId == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientVisitRepository.AddPatientVitalSignData(patientVitalSignData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To save patient medication data
        /// </summary>
        [HttpPost("addmedication")]
        public IActionResult AddMedicationData(Medication patientmedicationData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (patientmedicationData.AppointmentId == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientVisitRepository.AddPatientMedicationData(patientmedicationData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To save patient procedure data
        /// </summary>
        [HttpPost("addprocedure")]
        public IActionResult AddProcedureData(Procedure patientprocedureData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (patientprocedureData.AppointmentId == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientVisitRepository.AddPatientProcedureData(patientprocedureData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To save patient diagnosis data
        /// </summary>
        [HttpPost("adddiagnosis")]
        public IActionResult AddDiagnosisData(Diagnosis patientdiagnosisData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (patientdiagnosisData.AppointmentId == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientVisitRepository.AddPatientDiagnosisData(patientdiagnosisData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To save patient procedure data
        /// </summary>
        [HttpPost("addallergy")]
        public IActionResult AddAllergyData(PatientAllergy patientallergyData)
        {
            try
            {
                ResultModel res = new ResultModel();
                if (patientallergyData.PatientId == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    res = _patientVisitRepository.AddPatientAllergyData(patientallergyData);
                    return Ok(res);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To get patient visitdetails data
        /// </summary>
        [HttpGet("getvitalsignsdata")]
        public IActionResult GetVitalSignsDataByAppointmentId(int? appointmentid)
        {
            PatientVitalSign data = new PatientVitalSign();
            try
            {
                ResultModel res = new ResultModel();
                if (appointmentid == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientVisitRepository.GetPatientVitalSignByAppointmentId(appointmentid);
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To get patient visitdetails data
        /// </summary>
        [HttpGet("getdiagnosis")]
        public IActionResult GetPatientDiagnosisByAppointmentId(int? appointmentid)
        {
            List<PatientDiagnosis> data = new List<PatientDiagnosis>();
            try
            {
                ResultModel res = new ResultModel();
                if (appointmentid == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientVisitRepository.GetPatientDiagnosisByAppointmentId(appointmentid);
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        [HttpGet("getmedication")]
        public IActionResult GetPatientMedicationByAppointmentId(int? appointmentid)
        {
            List<PatientMedication> data = new List<PatientMedication>();
            try
            {
                ResultModel res = new ResultModel();
                if (appointmentid == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientVisitRepository.GetPatientMedicationByAppointmentId(appointmentid);
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To get patient visitdetails data
        /// </summary>
        [HttpGet("getprocedure")]
        public IActionResult GetPatientProcedureByAppointmentId(int? appointmentid)
        {
            List<PatientProcedure> data = new List<PatientProcedure>();
            try
            {
                ResultModel res = new ResultModel();
                if (appointmentid == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientVisitRepository.GetPatientProcedureByAppointmentId(appointmentid);
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        /// <summary>
        /// To get allergy data
        /// </summary>
        [HttpGet("getallergymasterdata")]
        public IActionResult GetAllergyData()
        {
            List<AllergyMaster> data = new List<AllergyMaster>();
            try
            {
                data = _patientVisitRepository.GetAllergyMasterData();

                if (data == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To get diagnosis master data
        /// </summary>
        [HttpGet("getdiagnosismasterdata")]
        public IActionResult GetDiagnosisData()
        {
            List<DiagnosisMaster> data = new List<DiagnosisMaster>();
            try
            {
                data = _patientVisitRepository.GetDiagnosisMasterData();

                if (data == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To get procedure master data
        /// </summary>
        [HttpGet("getproceduremasterdata")]
        public IActionResult GetProcedureData()
        {
            List<ProcedureMaster> data = new List<ProcedureMaster>();
            try
            {
                data = _patientVisitRepository.GetProcedureMasterData();

                if (data == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        [HttpGet("getallergy")]
        public IActionResult GetPatientAllergyByPatientId(int? patientid)
        {
            List<PatientAllergyVisit> data = new List<PatientAllergyVisit>();
            try
            {
                ResultModel res = new ResultModel();
                if (patientid == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    data = _patientVisitRepository.GetPatientAllergyByPatientId(patientid);
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }
        [HttpGet("getmedicinemasterdata")]
        public IActionResult GetMedicineData()
        {
            List<MedicineMaster> data = new List<MedicineMaster>();
            try
            {
                data = _patientVisitRepository.GetMedicineMasterData();

                if (data == null)
                {
                    return BadRequest(new Exception("Unable to fetch record"));
                }
                else
                {
                    return Ok(data);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }
        }

        /// <summary>
        /// To download excel file
        /// </summary>
        [HttpGet("getexcelreport")]
        public IActionResult DownloadExcelReport(int appointmentId, int patientId)
        {
            try
            {
                ListtoDataTableConverter convert = new ListtoDataTableConverter(_patientVisitRepository);
                MemoryStream mem = new MemoryStream();
                mem = convert.CreateExcel(appointmentId, patientId);
                return File(mem.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Report.xlsx");
                //return File(mem.ToArray(), "application/octet-stream","Report.xlsx");

            }
            catch (Exception e)
            {
                return BadRequest();
            }
        }


    }
}
