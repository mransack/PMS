﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ScheduleManagementServer.Services
{
    public class ViewAppointments
    {
        public int ?Id { get; set; }
        public string drname { get; set; }
        public string patientname { get; set; }
        public string date { get; set; }
        public string fromtime { get; set; }
        public string totime { get; set; }
        public int drid { get; set; }
        public int patientid { get; set; }
        public bool isApproved { get; set; }
        public string reason { get; set; }
        public string drDisplayId { get; set; }
        public string patientDisplayId { get; set; }
        public string description { get; set; }
    }
}
