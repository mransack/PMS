import { Component, Input, OnInit,Output,EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator} from '@angular/forms';
import { observable, Observable } from 'rxjs';
import { PatientVisit } from '../../Models/patientvisit';
import { PatientService} from '../../services/patient.service';
import { PatientAllergy } from '../../Models/patientallergy1';
import { PatientDiagnosis } from '../../Models/patientdiagnosis';
import { PatientProcedure } from '../../Models/patientprocedure';
import { PatientMedication } from '../../Models/patientmedication';
import { ToasterPosition } from '../../../app/core/ToasterPosition';
import { ToasterService } from '../../core/ToasterService';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-patient-visit-nurse',
  templateUrl: './patient-visit-nurse.component.html',
  styleUrls: ['./patient-visit-nurse.component.css']
})
export class PatientVisitNurseComponent implements OnInit {
  public ob :Observable<string>;
  public obpv:Observable<PatientVisit[]>;
  public oballergy:Observable<PatientAllergy[]>;
  public obdiagnosis:Observable<PatientDiagnosis[]>;
  public obprocedure:Observable<PatientProcedure[]>;
  public obmedication:Observable<PatientMedication[]>;
  success:boolean;
  public patientvisitnurse;
  public patienvisitallergy;
  msg:string="";
  public allergytype: string;
  public chkFatal: string;
  public AllergyRows: Array<{allergytype: string, chkFatal: boolean}> = [];
  public DiagnosisRows: Array<{diagnosistype: string, diagnosisdescription: string}> = [];
  public ProcedureRows: Array<{proceduretype: string, proceduredescription: string}> = [];
  public MedicationRows: Array<{medicationtype: string, medicationdescription: string}> = [];

  @Input()  aId:number;
  @Input()  pId:number;
  @Output("parentFun") parentFun: EventEmitter<any> = new EventEmitter();

  public patientvisitdata: PatientVisit[]=[];
  public patientAllergyData: PatientAllergy[]=[];
  public patientDiagnosisData: PatientDiagnosis[]=[];
  public patientProcedureData: PatientProcedure[]=[];
  public patientMedicationData: PatientMedication[]=[];
  public allergyMaster:any;

  fg: FormGroup = new FormGroup({
    height: new FormControl('',Validators.required),
    weight: new FormControl('',Validators.required),
    bloodpressuresystolic: new FormControl('',Validators.required),
    bloodpressurediastolic: new FormControl('',Validators.required),
    bodytemperature: new FormControl('',Validators.required),
    respirationrate : new FormControl('',Validators.required)//,
    // ApptID: new FormControl('',Validators.required),
    // PtID: new FormControl('',Validators.required)   
  });
  constructor(private practitionersvc: PatientService,private toaster: ToasterService,private spinner:NgxSpinnerService ) { }

  AddAllergy() {           
    //this.AllergyRows.push( {allergytype: this.allergytype, chkFatal: this.chkFatal==null?'false':'true' } );
    this.patienvisitallergy = new PatientAllergy(parseInt(this.allergytype.toString()),
    this.chkFatal==null?false:true,parseInt(this.pId.toString()));
    this.ob = this.practitionersvc.SavePatientVisitAllergyData(this.patienvisitallergy)
    
    this.ob.subscribe(      
      data => { 
        console.log(data);      
        console.log("Output Is: "+data["allergy"]); 
        this.msg = data["firstname"]+ ", has Registered Successfully" },
      (error: any) => console.log("Error in saving patientvisitallergy data")
      );
    this.allergytype = null;
    this.chkFatal = null;
    this.loadAllergyData(this.pId);
  }

  SavePatientVisitNurse():void
  {
    let operation:string="";
    console.log(this.fg.value.height);
    this.patientvisitnurse=new PatientVisit(
      parseInt(this.pId.toString()),parseInt(this.aId.toString()),parseInt(this.fg.value.height),
      parseInt(this.fg.value.weight),parseInt(this.fg.value.bloodpressuresystolic),
      parseInt(this.fg.value.bloodpressurediastolic),parseInt(this.fg.value.bodytemperature)
      ,parseInt(this.fg.value.respirationrate)); 
      debugger;     
      if(this.patientvisitdata["id"] > 0)
      {          
          operation="PATCH";  
          this.patientvisitnurse.appointmentid=this.patientvisitdata["appointmentId"]; 
          console.log(this.patientvisitnurse);       
      }
      else
      {
        operation="POST";
      }
    if(this.fg.invalid==false)
    { 
      this.ob = this.practitionersvc.SavePatientVisitData(this.patientvisitnurse,operation)

      this.ob.subscribe(      
        data => { 
          console.log(data); 
          if(data !=null)
          {
          this.success = true;
          this.sendMessage();
          this.toaster.success("Success",data["response"],ToasterPosition.topFull,this.functioncallbackFunction)   
          }     
          console.log("Output Is: "+data["height"]); 
          this.msg = data["firstname"]+ ", has Registered Successfully" },
        (error: any) => console.log("Error in saving patientvisitnurse data")
        );
    }
  }
  loadAppointmentData(aId:number)
  {    
   this.obpv=this.practitionersvc.GetPatientVisitDataByID(this.aId);
   this.obpv.subscribe(
     (pv:PatientVisit[])=>{this.patientvisitdata=pv;
      console.log(this.patientvisitdata)       
       console.log(this.patientvisitdata["height"])
     this.fg.patchValue({
       "height": this.patientvisitdata["height"],
       "weight": this.patientvisitdata["weight"],
       "bloodpressuresystolic": this.patientvisitdata["bloodPressureSystolic"],
       "bloodpressurediastolic":this.patientvisitdata["bloodPressureDiastolic"],
       "bodytemperature":this.patientvisitdata["bodyTemperature"],
       "respirationrate":this.patientvisitdata["respirationRate"]       
     })
   },
   (error:any)=>console.log('fails to load nurse data')
   );
  }
  loadAllergyData(pId:number)
  {    
    this.AllergyRows=[];
   this.oballergy=this.practitionersvc.GetPatientAllergyDataByPatientID(this.pId);
   this.oballergy.subscribe(
     (pv:PatientAllergy[])=>{this.patientAllergyData=pv;             
       for (let i = 0; i < this.patientAllergyData.length; i++) {
        this.AllergyRows.push( {allergytype: this.patientAllergyData[i].allergyName, 
          chkFatal: this.patientAllergyData[i].fatalAllergy } );
      }
       
   },
   (error:any)=>console.log('fails to load allergy data')
   );
  }
  loadDiagnosisData(aId:number)
  {   
   this.obdiagnosis=this.practitionersvc.GetPatientDiagnosisDataByAppointmentID(this.aId);
   this.obdiagnosis.subscribe(
     (pv:PatientDiagnosis[])=>{this.patientDiagnosisData=pv;             
       for (let i = 0; i < this.patientDiagnosisData.length; i++) {
        this.DiagnosisRows.push( {diagnosistype: this.patientDiagnosisData[i].diagnosisCode, 
          diagnosisdescription: this.patientDiagnosisData[i].diagnosisDescription } );
      }
       
   },
   (error:any)=>console.log('fails to load allergy data')
   );
  }
  loadProcedureData(aId:number)
  {   
    
   this.obprocedure=this.practitionersvc.GetPatientProcedureDataByAppointmentID(this.aId);
   this.obprocedure.subscribe(
     (pv:PatientProcedure[])=>{this.patientProcedureData=pv;      
       console.log(this.patientProcedureData[0])
       for (let i = 0; i < this.patientProcedureData.length; i++) {
        this.ProcedureRows.push( {proceduretype: this.patientProcedureData[i].procedureCode, 
          proceduredescription: this.patientProcedureData[i].procedureDescription } );
      }
       
   },
   (error:any)=>console.log('fails to load allergy data')
   );
  }
  loadMedicationData(aId:number)
  {   
    
    this.obmedication=this.practitionersvc.GetPatientMedicationDataByAppointmentID(this.aId);
    this.obmedication.subscribe(
      (pv:PatientMedication[])=>{this.patientMedicationData=pv;      
        console.log(this.patientMedicationData[0])
        for (let i = 0; i < this.patientMedicationData.length; i++) {
         this.MedicationRows.push( {medicationtype: this.patientMedicationData[i].medicineStrength,          
         medicationdescription: this.patientMedicationData[i].description} );
       }
        
    },
    (error:any)=>console.log('fails to load allergy data')
    );
   }
  ngOnInit(): void {
    this.loadAppointmentData(this.aId);
    this.loadAllergyData(this.pId);
    this.loadDiagnosisData(this.aId);
    this.loadProcedureData(this.aId);
    this.loadMedicationData(this.aId);
    // this.fg.patchValue({      
    //   "ApptID":"A0"+this.aId,
    //   "PtID":"P0"+this.pId
    // })
    this.loadAllergyMaster();
  }
  functioncallbackFunction(){
    this.success=true;
  }
  loadAllergyMaster()
  {
    this.oballergy=this.practitionersvc.GetAllergyMasterVisit();
    this.oballergy.subscribe(
      (data:any)=>{        
      this.allergyMaster=data;      
      }      
    )
    console.log(this.allergyMaster);
  }
  sendMessage() {
    //this.messageEvent.emit(this.message);
    this.parentFun.emit();
  }

}
