﻿using AuthServer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using AuthServer.Infrastructure.Models;

namespace AuthServer.Infrastructure.Services
{
	public interface IRegistrationRepo
	{
		public void AddPatient(UsersModel model);
		
		public void AddDoctor(UsersModel model);
		
		public void AddNurse(UsersModel model);
		
		public void UpdateUserDetails(UsersModel model);

		public void UpdateDocStatus(UsersModel model);
		
		public void UpdateNurseStatus(UsersModel model);
		
		public void UpdatePatientStatus(UsersModel model);
		
		public AspNetUser UserLoginDetails(string username);

		public void FailureLogin(string username);

		public void SuccessLogin(string username);
	}
}
