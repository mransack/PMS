export class UserModel{
    constructor(
        email:string,
        oldPassword: string,
        newPassword: string,
        confirmPassword:string,
    ){}
}