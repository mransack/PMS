﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ScheduleManagementServer.Services
{
    public class DoctorFilterAttributes
    {
        public string city { get; set; }
        public string speciality { get; set; }
        public string gender { get; set; }
    }
}
