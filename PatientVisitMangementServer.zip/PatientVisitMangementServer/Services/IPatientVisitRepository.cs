﻿using PatientVisitMangementServer.Data.AppDbContext;
using PatientVisitMangementServer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientVisitMangementServer.Services
{
    public interface IPatientVisitRepository
    {
        ResultModel AddPatientVitalSignData(PatientVitalSign vitalSignData);
        ResultModel AddPatientDiagnosisData(Diagnosis diagnosisData);
        ResultModel AddPatientProcedureData(Procedure procedureData);
        ResultModel AddPatientMedicationData(Medication medicationData);
        ResultModel AddPatientAllergyData(PatientAllergy allergydata);
        PatientVitalSign GetPatientVitalSignByAppointmentId(int ?appointmentid);
        List<PatientDiagnosis> GetPatientDiagnosisByAppointmentId(int? appointmentid);
        List<PatientMedication> GetPatientMedicationByAppointmentId(int? appointmentid);
        List<PatientProcedure> GetPatientProcedureByAppointmentId(int? appointmentid);
        List<AllergyMaster> GetAllergyMasterData();
        List<DiagnosisMaster> GetDiagnosisMasterData();
        List<ProcedureMaster> GetProcedureMasterData();
        List<MedicineMaster> GetMedicineMasterData();
        List<PatientAllergyVisit> GetPatientAllergyByPatientId(int? patientid);
        List<ViewAppointments> GetAppointmentsHistoryForPatient(int appointmentId);

    }
    public class PatientVisitDbRepository : IPatientVisitRepository
    {
        PMSYSTEMContext _dbContext = new PMSYSTEMContext();        
        public PatientVisitDbRepository(PMSYSTEMContext dbContext)
        {
            this._dbContext = dbContext;
        }        
        public ResultModel AddPatientVitalSignData(PatientVitalSign vitalSignData)
        {
            ResultModel rs = new ResultModel();                        
            if (vitalSignData != null)
            {
                PatientVitalSign patientvitalsigns = _dbContext.PatientVitalSigns.SingleOrDefault(x => x.AppointmentId == vitalSignData.AppointmentId);
                if (patientvitalsigns != null)
                {
                    patientvitalsigns.BloodPressureDiastolic = vitalSignData.BloodPressureDiastolic;
                    patientvitalsigns.BloodPressureSystolic = vitalSignData.BloodPressureSystolic;
                    patientvitalsigns.BodyTemperature = vitalSignData.BodyTemperature;
                    patientvitalsigns.Height = vitalSignData.Height;
                    patientvitalsigns.Weight = vitalSignData.Weight;
                    patientvitalsigns.RespirationRate = vitalSignData.RespirationRate;
                    patientvitalsigns.ModifiedOn = DateTime.Now;
                    _dbContext.SaveChanges();
                    rs.Code = 1;
                    rs.Response = "Patient Vital signs data updated successfully";
                }
                else
                {
                    vitalSignData.CreatedOn = DateTime.Now;
                    this._dbContext.PatientVitalSigns.Add(vitalSignData);
                    _dbContext.SaveChanges();
                    rs.Code = 1;
                    rs.Response = "Patient Vital signs data saved successfully";
                }                    
                
            }            
            return rs;
        }
        public ResultModel AddPatientDiagnosisData(Diagnosis diagnosisData)
        {
            ResultModel rs = new ResultModel();
            if (diagnosisData != null)
            {
                diagnosisData.CreatedOn = DateTime.Now;
                this._dbContext.Diagnoses.Add(diagnosisData);
                _dbContext.SaveChanges();
                rs.Code = 1;
                rs.Response = "Patient Diagnosis data saved successfully";
            }
            return rs;
        }
        public ResultModel AddPatientProcedureData(Procedure procedureData)
        {
            ResultModel rs = new ResultModel();
            if (procedureData != null)
            {
                procedureData.CreatedOn = DateTime.Now;
                this._dbContext.Procedures.Add(procedureData);
                _dbContext.SaveChanges();
                rs.Code = 1;
                rs.Response = "Patient procedure data saved successfully";
            }
            return rs;
        }
        public ResultModel AddPatientMedicationData(Medication medicationData)
        {
            ResultModel rs = new ResultModel();
            if (medicationData != null)
            {
                medicationData.CreatedOn = DateTime.Now;
                this._dbContext.Medications.Add(medicationData);
                _dbContext.SaveChanges();
                rs.Code = 1;
                rs.Response = "Patient medication data saved successfully";
            }
            return rs;
        }
        public ResultModel AddPatientAllergyData(PatientAllergy allergyData)
        {
            ResultModel rs = new ResultModel();
            if (allergyData != null)
            {
                allergyData.CreatedOn = DateTime.Now;
                this._dbContext.PatientAllergies.Add(allergyData);
                _dbContext.SaveChanges();
                rs.Code = 1;
                rs.Response = "Patient allergy data saved successfully";
            }
            return rs;
        }
        public PatientVitalSign GetPatientVitalSignByAppointmentId(int ?appointmentid)
        {

            PatientVitalSign patientVitalSign = _dbContext.PatientVitalSigns.SingleOrDefault(x => x.AppointmentId == appointmentid);
            PatientVitalSign data = new PatientVitalSign();
            if (patientVitalSign != null)
            {
                data = new PatientVitalSign
                {
                    Id = patientVitalSign.Id,
                    PatientId = patientVitalSign.PatientId,
                    Height = patientVitalSign.Height,
                    Weight = patientVitalSign.Weight,
                    BloodPressureSystolic = patientVitalSign.BloodPressureSystolic,
                    BloodPressureDiastolic = patientVitalSign.BloodPressureDiastolic,
                    BodyTemperature = patientVitalSign.BodyTemperature,
                    RespirationRate = patientVitalSign.RespirationRate,
                    AppointmentId = patientVitalSign.AppointmentId,
                    CreatedOn = patientVitalSign.CreatedOn,
                    CreatedBy = patientVitalSign.CreatedBy,
                    ModifiedOn = patientVitalSign.ModifiedOn,
                    ModifiedBy = patientVitalSign.ModifiedBy,
                };
            }
            return data;
        }
        public List<PatientDiagnosis> GetPatientDiagnosisByAppointmentId(int? appointmentid)
        {

            List<PatientDiagnosis> allergyModels = new List<PatientDiagnosis>();
            PatientDiagnosis model;
            //patientAllergies = _dbContext.PatientAllergies.Where(x => x.PatientId == patientId).ToList();
            var data = (from a in _dbContext.DiagnosisMasters
                        join b in _dbContext.Diagnoses
                        on new { cond1 = a.Id.ToString() } equals new { cond1 = b.DiagnosisId.ToString() }
                        where b.AppointmentId == appointmentid
                        select new
                        {
                            AppointmentId = b.AppointmentId,
                            DiagnosisId = b.DiagnosisId,
                            DiagnosisCode = a.DiagnosisCode,
                            DiagnosisDescription = a.DiagnosisDescription,
                            Diagnosystype = a.Diagnosystype
                        }).ToList();            
            foreach (var item in data)
            {
                model = new PatientDiagnosis
                {
                    AppointmentId = Convert.ToInt32(item.AppointmentId),
                    DiagnosisId = Convert.ToInt32(item.DiagnosisId),
                    DiagnosisCode = item.DiagnosisCode,
                    DiagnosisDescription = item.DiagnosisDescription,
                    Diagnosystype = item.Diagnosystype
                };
                allergyModels.Add(model);
            }
            return allergyModels;
        }
        public List<PatientMedication> GetPatientMedicationByAppointmentId(int? appointmentid)
        {

            List<PatientMedication> allergyModels = new List<PatientMedication>();
            PatientMedication model;
            //patientAllergies = _dbContext.PatientAllergies.Where(x => x.PatientId == patientId).ToList();
            var data = (from a in _dbContext.MedicineMasters
                        join b in _dbContext.Medications
                        on new { cond1 = a.Id.ToString() } equals new { cond1 = b.MedicationId.ToString() }
                        where b.AppointmentId == appointmentid
                        select new
                        {
                            AppointmentId = b.AppointmentId,
                            MedicationId = b.MedicationId,
                            MedicineStrength = a.MedicineStrength,
                            Description = b.Description                            
                        }).ToList();
            foreach (var item in data)
            {
                model = new PatientMedication
                {
                    AppointmentId = Convert.ToInt32(item.AppointmentId),
                    MedicationId = Convert.ToInt32(item.MedicationId),
                    MedicineStrength = item.MedicineStrength,
                    Description = item.Description
                };
                allergyModels.Add(model);
            }
            return allergyModels;
        }
        public List<PatientProcedure> GetPatientProcedureByAppointmentId(int? appointmentid)
        {

            List<PatientProcedure> allergyModels = new List<PatientProcedure>();
            PatientProcedure model;            
            var data = (from a in _dbContext.ProcedureMasters
                        join b in _dbContext.Procedures
                        on new { cond1 = a.Id.ToString() } equals new { cond1 = b.ProcedureId.ToString() }
                        where b.AppointmentId == appointmentid
                        select new
                        {
                            AppointmentId = b.AppointmentId,
                            ProcedureId = b.ProcedureId,
                            ProcedureCode = a.ProcedureCode,
                            ProcedureDescription = a.ProcedureDescription,                            
                        }).ToList();
            foreach (var item in data)
            {
                model = new PatientProcedure
                {
                    AppointmentId = Convert.ToInt32(item.AppointmentId),
                    ProcedureId = Convert.ToInt32(item.ProcedureId),
                    ProcedureCode = item.ProcedureCode,
                    ProcedureDescription = item.ProcedureDescription                    
                };
                allergyModels.Add(model);
            }
            return allergyModels;
        }
        public List<PatientAllergyVisit> GetPatientAllergyByPatientId(int? patientid)
        {

            List<PatientAllergyVisit> allergyModels = new List<PatientAllergyVisit>();
            PatientAllergyVisit model;
            var data = (from a in _dbContext.AllergyMasters
                        join b in _dbContext.PatientAllergies
                        on new { cond1 = a.Id.ToString() } equals new { cond1 = b.AllergyId.ToString() }
                        where b.PatientId == patientid
                        select new
                        {
                            PatientId = b.PatientId,
                            AllergyId = b.AllergyId,
                            AllergyName = a.AllergyName,
                            FatalAllergy = b.FatalAllergy,
                        }).ToList();
            foreach (var item in data)
            {
                model = new PatientAllergyVisit
                {
                    PatientId = Convert.ToInt32(item.PatientId),
                    AllergyId = Convert.ToInt32(item.AllergyId),
                    AllergyName = item.AllergyName,
                    FatalAllergy = Convert.ToBoolean(item.FatalAllergy)
                };
                allergyModels.Add(model);
            }
            return allergyModels;
        }
        public List<AllergyMaster> GetAllergyMasterData()
        {
            List<AllergyMaster> allergyMaster = _dbContext.AllergyMasters.ToList();
            return allergyMaster;
        }
        public List<DiagnosisMaster> GetDiagnosisMasterData()
        {
            List<DiagnosisMaster> diagnosisMaster = _dbContext.DiagnosisMasters.ToList();
            return diagnosisMaster;
        }
        public List<ProcedureMaster> GetProcedureMasterData()
        {
            List<ProcedureMaster> procedureMaster = _dbContext.ProcedureMasters.ToList();
            return procedureMaster;
        }
        public List<MedicineMaster> GetMedicineMasterData()
        {
            List<MedicineMaster> medicineMaster = _dbContext.MedicineMasters.ToList();
            return medicineMaster;
        }


        public List<ViewAppointments> GetAppointmentsHistoryForPatient(int appointmentId)
        {
            List<ViewAppointments> viewappointments = new List<ViewAppointments>();
            ViewAppointments model;
            var data = (from a in _dbContext.DoctorMasters
                        join b in _dbContext.Appointments
                        on new { cond1 = a.Id.ToString() } equals new { cond1 = b.DoctorId.ToString() }
                        join c in _dbContext.PatientMasters
                        on new { cond1 = b.PatientId.ToString() } equals new { cond1 = c.Id.ToString() }
                        where b.Id == appointmentId
                        select new
                        {
                            Id = b.Id,
                            drname = a.FirstName + " " + a.LastName,
                            patientname = c.FirstName + " " + c.LastName,
                            date = b.MeetingStartTime.GetValueOrDefault().ToShortDateString(),
                            fromtime = b.MeetingStartTime.GetValueOrDefault().ToShortTimeString(),
                            totime = b.MeetingEndTime.GetValueOrDefault().ToShortTimeString(),
                            drid = b.DoctorId,
                            patientid = b.PatientId,
                            isapproved = b.IsConfirmed,
                            reason = b.Notes,
                            drDisplayId = a.DoctorDisplayId,
                            patientDisplayId = c.PatientDisplayId,
                            description = b.Description
                        }).ToList();
            foreach (var item in data)
            {
                model = new ViewAppointments
                {
                    Id = Convert.ToInt32(item.Id),
                    drname = item.drname,
                    patientname = item.patientname,
                    date = item.date.ToString(),
                    fromtime = (item.fromtime),
                    totime = (item.totime),
                    drid = Convert.ToInt32(item.drid),
                    patientid = Convert.ToInt32(item.patientid),
                    isApproved = Convert.ToBoolean(item.isapproved),
                    reason = item.reason,
                    drDisplayId = item.drDisplayId,
                    patientDisplayId = item.patientDisplayId,
                    description = item.description
                };
                viewappointments.Add(model);
            }
            return viewappointments;
        }
    }
}
