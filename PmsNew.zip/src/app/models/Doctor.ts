export class Doctors{
    constructor(      
        public id: number=0,
        public firstname:string="",
        public lastname:string="",
        public gender:string="",
        public dob:string="",
        public speciality:string="",
        public city:string="",
        public contact:string="",
        public email:string=""
     )
    {
        
    }

  //   get Id() { return this.id };
  //   set Id(data: number) { this.id = data };

  // get FirstName() { return this.firstname };
  // set FirstName(data: string) { this.firstname = data };

  // get LastName() { return this.lastname };
  // set LastName(data: string) { this.lastname = data };

  // get DOB() { return this.dob };
  // set DOB(data: string) { this.dob = data };

  // get Contact() { return this.contact };
  // set Contact(data: string) { this.contact = data };

  // get Email() { return this.email };
  // set Email(data: string) { this.email = data };

  // get Speciality() { return this.speciality };
  // set Speciality(data: string) { this.speciality = data };

  // get Gender() { return this.gender };
  // set Gender(data: string) { this.gender = data };

  // get City() { return this.city };
  // set City(data: string) { this.city = data };
}