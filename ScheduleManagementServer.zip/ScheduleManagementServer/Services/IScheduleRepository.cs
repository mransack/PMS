﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ScheduleManagementServer.Data.AppDbContext;
using ScheduleManagementServer.Models;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace ScheduleManagementServer.Services
{
    public interface IScheduleRepository
    {
        List<DoctorMaster> GetAllDoctors();
        List<DoctorMaster> GetFilteredDoctors(string city = "", string speciality = "", string gender = "");
        AppoinmentModel GetAppoinmentData(string doctorId, string patientUserName);
        ResultModel SaveAppoinmentData(AppoinmentModel model);        
        List<ViewAppointments> GetAllAppointmentsData();
        List<ViewAppointments> GetAppointmentsHistoryForPatient(string userName);
        ResultModel UpdateAppointmentAction(ViewAppointments viewappointmentsmodel);
        ViewAppointments GetAppointmentActionData(int appointmentid);
        void AppointmentActionNotification(ViewAppointments viewappointmentsmodel); 
    }

    public class ScheduleDbRepository : IScheduleRepository
    {
        PMSYSTEMContext _dbContext = new PMSYSTEMContext();

        public ScheduleDbRepository(PMSYSTEMContext dbContext)
        {
            this._dbContext = dbContext;
        }

        public List<DoctorMaster> GetAllDoctors()
        {
            List<DoctorMaster> data = new List<DoctorMaster>();
                data = _dbContext.DoctorMasters.ToList();
            return data;
        }

        public List<DoctorMaster> GetFilteredDoctors(string city = "", string speciality = "", string gender = "")
        {
            StringBuilder condition = new StringBuilder();
            if(!string.IsNullOrEmpty(city))
            {
                condition.Append("city='" + city + "'");
            }
            if(!string.IsNullOrEmpty(speciality))
            {
                condition.Append(string.IsNullOrEmpty(condition.ToString()) ? "speciality='" + speciality + "'" : " and speciality='" + speciality + "'");
            }
            if (!string.IsNullOrEmpty(gender))
            {
                condition.Append(string.IsNullOrEmpty(condition.ToString()) ? "gender='" + gender + "'" : " and gender='" + gender + "'");
            }


            List<DoctorMaster> data = new List<DoctorMaster>();
            if (string.IsNullOrEmpty(condition.ToString()))
            {
                data = _dbContext.DoctorMasters.ToList();
            }
            else
            {
                //data = _dbContext.DoctorMasters.Where(x => x.Gender == gender).ToList();
                data = _dbContext.DoctorMasters.FromSqlRaw("Select * from DoctorMaster where "+ condition.ToString() + "").ToList();
            }
            return data;
        }

        public AppoinmentModel GetAppoinmentData(string doctorId, string patientUserName)
        {
            AspNetUser user = _dbContext.AspNetUsers.SingleOrDefault(x => x.UserName == patientUserName);
            PatientMaster patientMaster = _dbContext.PatientMasters.SingleOrDefault(x => x.UserLoginDetailsId == user.Id);
            DoctorMaster doctorMaster = _dbContext.DoctorMasters.SingleOrDefault(x => x.Id == Convert.ToInt32(doctorId));
            AppoinmentModel data = new AppoinmentModel
            {
                drname = doctorMaster.FirstName + " " + doctorMaster.LastName,
                patientname = patientMaster.FirstName + " " + patientMaster.LastName,       
                drid = doctorMaster.Id.ToString(),
                patientid = patientMaster.Id.ToString(),
                speciality=doctorMaster.Speciality
            };
            return data;
        }

        public ResultModel SaveAppoinmentData(AppoinmentModel model)
        {
            ResultModel rs = new ResultModel();
            Appointment appointment = new Appointment
            {
                Description = model.description,
                DoctorId=Convert.ToInt32(model.drid),
                MeetingStartTime=Convert.ToDateTime(model.date+" "+ model.fromtime),
                MeetingEndTime= Convert.ToDateTime(model.date + " " + model.totime),
                PatientId=Convert.ToInt32(model.patientid),
                CreatedOn=DateTime.Now,
                ModifiedOn=DateTime.Now
            };
            _dbContext.Appointments.Add(appointment);
            _dbContext.SaveChanges();
            SetNotification(Convert.ToInt32(model.drid),model.patientname);
            rs.Code = 1;
            return rs;
        }

        public void SetNotification(int doctorId, string patientName)
        {
            string userLoginDetailsId = _dbContext.DoctorMasters.Where(x => x.Id == Convert.ToInt32(doctorId)).SingleOrDefault().UserLoginDetailsId;
            Notification notification = new Notification
            { 
                Description="Received new appointment request from "+patientName+"",
                UserLoginDetailsId=userLoginDetailsId,
                IsSeen=false,
                CreatedOn=DateTime.Now,
                ModifiedOn=DateTime.Now
            };
            _dbContext.Notifications.Add(notification);
            _dbContext.SaveChanges();
        }
        public List<ViewAppointments> GetAllAppointmentsData()
        {
            List<ViewAppointments> viewappointments = new List<ViewAppointments>();
            ViewAppointments model;
            var data = (from a in _dbContext.DoctorMasters
                        join b in _dbContext.Appointments                        
                        on new { cond1 = a.Id.ToString() } equals new { cond1 = b.DoctorId.ToString() }
                        join c in _dbContext.PatientMasters
                        on new { cond1 = b.PatientId.ToString() } equals new { cond1 = c.Id.ToString() }
                        select new
                        {
                            Id = b.Id,
                            drname = a.FirstName+" "+a.LastName,
                            patientname = c.FirstName+" "+c.LastName,
                            date = b.MeetingStartTime.GetValueOrDefault().ToShortDateString(),
                            fromtime = b.MeetingStartTime.GetValueOrDefault().ToShortTimeString(),
                            totime = b.MeetingEndTime.GetValueOrDefault().ToShortTimeString(),
                            drid = b.DoctorId,
                            patientid=b.PatientId,
                            isapproved = b.IsConfirmed,
                            reason = b.Notes,
                            drdisplayid = a.DoctorDisplayId,
                            patientdisplayid = c.PatientDisplayId,
                            description = b.Description
                        }).ToList();
            foreach (var item in data)
            {
                model = new ViewAppointments
                {
                    Id = Convert.ToInt32(item.Id),
                    drname = item.drname,
                    patientname = item.patientname,
                    date = item.date.ToString(),
                    fromtime = (item.fromtime),
                    totime = (item.totime),
                    drid = Convert.ToInt32(item.drid),
                    patientid = Convert.ToInt32(item.patientid),
                    isApproved = Convert.ToBoolean(item.isapproved),
                    reason = item.reason,
                    drDisplayId = item.drdisplayid,
                    patientDisplayId = item.patientdisplayid,
                    description = item.description
                };
                viewappointments.Add(model);
            }
            return viewappointments;
        }
        public ResultModel UpdateAppointmentAction(ViewAppointments viewappointmentsmodel)
        {
            ResultModel rs = new ResultModel();
            if (viewappointmentsmodel != null)
            {
                Appointment appointment = _dbContext.Appointments.SingleOrDefault(x => x.Id == viewappointmentsmodel.Id);
                if (appointment != null)
                {
                    appointment.IsConfirmed = viewappointmentsmodel.isApproved;
                    appointment.Notes = viewappointmentsmodel.reason;
                    appointment.RespondedOn = DateTime.Now;
                    appointment.ModifiedOn = DateTime.Now;
                    _dbContext.SaveChanges();
                    rs.Code = 1;
                    rs.Response = "Appointment data updated successfully";
                }     
                else
                {
                    rs.Code = 4;
                    rs.Response = "Appointment details not found.";
                }
            }
            return rs;
        }
        public ViewAppointments GetAppointmentActionData(int appointmentid)
        {
            ViewAppointments model = new ViewAppointments();
            Appointment appointment = _dbContext.Appointments.SingleOrDefault(x => x.Id == appointmentid);
            model.isApproved = Convert.ToBoolean(appointment.IsConfirmed);
            model.reason = appointment.Notes;
            return model;
        }

        public List<ViewAppointments> GetAppointmentsHistoryForPatient(string userName)
        {
            AspNetUser user = _dbContext.AspNetUsers.SingleOrDefault(x => x.UserName == userName);
            int patientId = _dbContext.PatientMasters.Where(x => x.UserLoginDetailsId == user.Id).SingleOrDefault().Id;
            List<ViewAppointments> viewappointments = new List<ViewAppointments>();
            ViewAppointments model;
            var data = (from a in _dbContext.DoctorMasters
                        join b in _dbContext.Appointments
                        on new { cond1 = a.Id.ToString() } equals new { cond1 = b.DoctorId.ToString() }
                        join c in _dbContext.PatientMasters
                        on new { cond1 = b.PatientId.ToString() } equals new { cond1 = c.Id.ToString() }
                        where b.PatientId==patientId
                        select new
                        {
                            Id = b.Id,
                            drname = a.FirstName + " " + a.LastName,
                            patientname = c.FirstName + " " + c.LastName,
                            date = b.MeetingStartTime.GetValueOrDefault().ToShortDateString(),
                            fromtime = b.MeetingStartTime.GetValueOrDefault().ToShortTimeString(),
                            totime = b.MeetingEndTime.GetValueOrDefault().ToShortTimeString(),
                            drid = b.DoctorId,
                            patientid = b.PatientId,
                            isapproved = b.IsConfirmed,
                            reason = b.Notes,
                            drDisplayId=a.DoctorDisplayId,
                            patientDisplayId=c.PatientDisplayId,
                            description=b.Description
                        }).ToList();
            foreach (var item in data)
            {
                model = new ViewAppointments
                {
                    Id = Convert.ToInt32(item.Id),
                    drname = item.drname,
                    patientname = item.patientname,
                    date = item.date.ToString(),
                    fromtime = (item.fromtime),
                    totime = (item.totime),
                    drid = Convert.ToInt32(item.drid),
                    patientid = Convert.ToInt32(item.patientid),
                    isApproved = Convert.ToBoolean(item.isapproved),
                    reason = item.reason,
                    drDisplayId=item.drDisplayId,
                    patientDisplayId=item.patientDisplayId,
                    description=item.description
                };
                viewappointments.Add(model);
            }
            return viewappointments;
        }
        public void AppointmentActionNotification(ViewAppointments viewappointmentsmodel)
        {
            ResultModel rs = new ResultModel();
            if (viewappointmentsmodel != null)
            {
                string userLoginDetailsId = _dbContext.PatientMasters.Where(x => x.Id == Convert.ToInt32(viewappointmentsmodel.patientid)).SingleOrDefault().UserLoginDetailsId;
                if(viewappointmentsmodel.isApproved)
                {
                    Notification notification = new Notification
                    {
                        Description = "Your appointment is approved by doctor " + viewappointmentsmodel.drname + " for date "+viewappointmentsmodel.date+" and time "+viewappointmentsmodel.fromtime,
                        UserLoginDetailsId = userLoginDetailsId,
                        IsSeen = false,
                        CreatedOn = DateTime.Now,
                        ModifiedOn = DateTime.Now
                    };
                    _dbContext.Notifications.Add(notification);
                    _dbContext.SaveChanges();
                }
                else
                {
                    Notification notification = new Notification
                    {
                        Description = "Your appointment is rejected by doctor " + viewappointmentsmodel.drname + " for date " + viewappointmentsmodel.date +" due to "+viewappointmentsmodel.reason,
                        UserLoginDetailsId = userLoginDetailsId,
                        IsSeen = false,
                        CreatedOn = DateTime.Now,
                        ModifiedOn = DateTime.Now
                    };
                    _dbContext.Notifications.Add(notification);
                    _dbContext.SaveChanges();
                }
                
            }            
        }
    }
}
