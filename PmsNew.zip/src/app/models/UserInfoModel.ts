export class UserInfoModel{
    email: string;
    id: string;
    name: string;
    userName:string;
    phoneNumber:string;
    role:string;
    city:string;
    country:string;
    zipCode:string;
    constructor(
        email       :string,
        userName    :string,
        firstName   :string,
        lastName    :string,
    ){}
}