﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientVisitMangementServer.Services
{
    public class PatientProcedure
    {
        public int ProcedureId{ get; set; }
        public int AppointmentId{ get; set; }
        public string ProcedureCode { get; set; }
        public string ProcedureDescription{ get; set; }
    }
}
