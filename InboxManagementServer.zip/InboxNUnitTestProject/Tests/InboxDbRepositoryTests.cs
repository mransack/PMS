﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InboxManagementServer.Models;
using InboxManagementServer.Services;
using Moq;
using Microsoft.AspNetCore.Mvc;

namespace InboxNUnitTestProject.Tests
{
    class InboxDbRepositoryTests
    {
        private InboxManagementServer.Data.AppDbContext.PMSYSTEMContext dbContext;
        [SetUp]
        public void Setup()
        {
            dbContext = new InboxManagementServer.Data.AppDbContext.PMSYSTEMContext();
        }

        [Test]
        public void GetNotificationColor()
        {
            var inboxDbRepository = new InboxDbRepository(dbContext);
            string color = inboxDbRepository.GetNotificationColor("true");

            Assert.AreEqual("green", color);
        }

        [Test]
        public void GetNotificationStatus()
        {
            var inboxDbRepository = new InboxDbRepository(dbContext);
            string status = inboxDbRepository.GetNotificationStatus("true");

            Assert.AreEqual("Approved", status);
        }
    }
}
