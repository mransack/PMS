﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientVisitMangementServer.Services
{
    public class PatientMedication
    {
        public int AppointmentId { get; set; }
        public int MedicationId { get; set; }
        public string MedicineStrength { get; set; }
        public string Description { get; set; }
    }
}
