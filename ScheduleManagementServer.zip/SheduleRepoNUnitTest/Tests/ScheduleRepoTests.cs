﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ScheduleManagementServer.Models;
using ScheduleManagementServer.Services;
using Moq;
using Microsoft.AspNetCore.Mvc;

namespace SheduleRepoNUnitTest.Tests
{
    class ScheduleRepoTests
    {
        private Mock<IScheduleRepository> iScheduleRepository;
        private List<DoctorMaster> lstDoctorMaster;
        private List<ViewAppointments> lstViewAppointments;

        [SetUp]
        public void Setup()
        {
            //Mock Setup
            iScheduleRepository = new Mock<IScheduleRepository>();

            //DoctorMaster List
            lstDoctorMaster = new List<DoctorMaster>();
            lstDoctorMaster.Add(new DoctorMaster() { Id= 6, UserLoginDetailsId= "0d6e700d-40cd-4eeb-b9ab-ea54bbedeb4d",DoctorDisplayId= "DT-0006",CreatedBy= null,
                                                     CreatedOn=Convert.ToDateTime("2021-03-09"),ModifiedBy= null,ModifiedOn= Convert.ToDateTime("2021-03 09"),     IsActive= true,
                                                     FirstName= "Doctor ",LastName= "3",EmailId= "dr3@ct.com",Dob= Convert.ToDateTime("2021-03-04"),Age= 0,Gender= "M",
                                                     City= "Kalyan",Title= null,PhoneNo= "9535456754",Speciality= "Pediatrician",Address= null });
            lstDoctorMaster.Add(new DoctorMaster()
            {
                Id = 6,
                UserLoginDetailsId = "0d6e700d-40cd-4eeb-b9ab-ea54bbedeb4d",
                DoctorDisplayId = "DT-0006",
                CreatedBy = null,
                CreatedOn = Convert.ToDateTime("2021-03 09"),
                ModifiedBy = null,
                ModifiedOn = Convert.ToDateTime("2021-03 09"),
                IsActive = true,
                FirstName = "Doctor ",
                LastName = "3",
                EmailId = "dr3@ct.com",
                Dob = Convert.ToDateTime("2021-03-04"),
                Age = 0,
                Gender = "M",
                City = "Kalyan",
                Title = null,
                PhoneNo = "9535456754",
                Speciality = "Pediatrician",
                Address = null
            });
            lstDoctorMaster.Add(new DoctorMaster()
            {
                Id = 6,
                UserLoginDetailsId = "0d6e700d-40cd-4eeb-b9ab-ea54bbedeb4d",
                DoctorDisplayId = "DT-0006",
                CreatedBy = null,
                CreatedOn = Convert.ToDateTime("2021-03 09"),
                ModifiedBy = null,
                ModifiedOn = Convert.ToDateTime("2021-03 09"),
                IsActive = true,
                FirstName = "Doctor ",
                LastName = "3",
                EmailId = "dr3@ct.com",
                Dob = Convert.ToDateTime("2021-03-04"),
                Age = 0,
                Gender = "F",
                City = "Kalyan",
                Title = null,
                PhoneNo = "9535456754",
                Speciality = "Pediatrician",
                Address = null
            });

            //ViewAppointments List
            lstViewAppointments = new List<ViewAppointments>();
            lstViewAppointments.Add(new ViewAppointments()
            {
                Id = 4,
                drname = "Doctor  Dr1",
                patientname = "vivek patil",
                date = "3/17/2021",
                fromtime = "8:26 PM",
                totime = "9:26 PM",
                drid = 4,
                patientid = 6,
                isApproved = false,
                reason = "sdsadsdsd",
                drDisplayId = "DT-0001",
                patientDisplayId = "PT-0004",
                description = "for Strong Fever and Headache"
            });
            lstViewAppointments.Add(new ViewAppointments()
            {
                Id = 5,
                drname = "Doctor  Dr1",
                patientname = "vivek patil",
                date = "3/17/2021",
                fromtime = "8:26 PM",
                totime = "9:26 PM",
                drid = 4,
                patientid = 6,
                isApproved = false,
                reason = "sdsadsdsd",
                drDisplayId = "DT-0001",
                patientDisplayId = "PT-0005",
                description = "for Strong Fever and Headache"
            });
            lstViewAppointments.Add(new ViewAppointments()
            {
                Id = 6,
                drname = "Doctor  Dr1",
                patientname = "vivek patil",
                date = "3/17/2021",
                fromtime = "8:26 PM",
                totime = "9:26 PM",
                drid = 4,
                patientid = 6,
                isApproved = false,
                reason = "sdsadsdsd",
                drDisplayId = "DT-0001",
                patientDisplayId = "PT-0006",
                description = "for Strong Fever and Headache"
            });
        }

        [Test]
        public void TestForGetAllDoctors()
        {
            iScheduleRepository.Setup(x => x.GetAllDoctors()).Returns(lstDoctorMaster.ToList());

            var scheduleController= new ScheduleManagementServer.Controllers.ScheduleController(iScheduleRepository.Object);
            var lstAllDoctorRecords = scheduleController.GetAllDoctorData();

            var okResult = lstAllDoctorRecords as OkObjectResult;

            // assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);

            var lst=okResult.Value as List<DoctorMaster>;
            Assert.AreEqual(3, lst.Count);
        }

        [Test]
        public void TestForGetFilteredDoctors()
        {
            iScheduleRepository.Setup(x => x.GetFilteredDoctors("","","F")).Returns(lstDoctorMaster.Where(x=>x.Gender=="F").ToList());

            var scheduleController = new ScheduleManagementServer.Controllers.ScheduleController(iScheduleRepository.Object);
            var lstFilteredDoctorRecords = scheduleController.GetFilteredDoctorData("", "", "F");

            var okResult = lstFilteredDoctorRecords as OkObjectResult;

            // assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);

            var lst = okResult.Value as List<DoctorMaster>;
            Assert.AreEqual(1, lst.Count);
        }

        [Test]
        public void TestForGetAllAppointmentsData()
        {
            iScheduleRepository.Setup(x => x.GetAllAppointmentsData()).Returns(lstViewAppointments.ToList());

            var scheduleController = new ScheduleManagementServer.Controllers.ScheduleController(iScheduleRepository.Object);
            var lstAllAppointmentRecords = scheduleController.GetAllAppointmentsData();

            var okResult = lstAllAppointmentRecords as OkObjectResult;

            // assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);

            var lst = okResult.Value as List<ViewAppointments>;
            Assert.AreEqual(3, lst.Count);
        }


        [Test]
        public void GetAppointmentActionData()
        {
            iScheduleRepository.Setup(x => x.GetAppointmentActionData(6)).Returns(lstViewAppointments.Where(x=>x.Id==6).FirstOrDefault());

            var scheduleController = new ScheduleManagementServer.Controllers.ScheduleController(iScheduleRepository.Object);
            var AppointmentRecord = scheduleController.GetAppointmentActionData(6);

            var okResult = AppointmentRecord as OkObjectResult;

            // assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);

            var data = okResult.Value as ViewAppointments;
            Assert.AreEqual("PT-0006", data.patientDisplayId);
        }
    }
}
