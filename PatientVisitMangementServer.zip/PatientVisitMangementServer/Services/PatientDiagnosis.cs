﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientVisitMangementServer.Services
{
    public class PatientDiagnosis
    {
        public int AppointmentId { get; set; }
        public int DiagnosisId { get; set; }
        public string DiagnosisCode { get; set; }
        public string DiagnosisDescription { get; set; }
        public string Diagnosystype { get; set; }
    }
}
