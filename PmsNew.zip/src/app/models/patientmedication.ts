export class PatientMedication{
  constructor(              
      public medicationid:number=0,
      //public dosage:string="",
      public description:string="",
      //public patientid:string="",
      public appointmentid:number=0,
      public medicineStrength:string=""
   )
  {}

// get Medication() { return this.medication };
// set Medication(data: string) { this.medication = data };

// get Dosage() { return this.dosage };
// set Dosage(data: string) { this.dosage = data };

// get Medicationdescription() { return this.medicationdescription };
// set Medicationdescription(data: string) { this.medicationdescription = data };

// get Patientid() { return this.patientid };
// set Patientid(data: string) { this.patientid = data };

// get Appointmentid() { return this.appointmentid };
// set Appointmentid(data: string) { this.appointmentid = data };
}