export class CalenderNotification{
    constructor(
       public id:number=0,
       public title:string="",
       public date:string="",
       public time:string=""
     )
    {
        
    }
}